package com.github.curiousoddman.curious_images.domain.imports.metadata;

/**
 * Where a media's {@code capture_date} was sourced from, in priority order
 * (highest priority first). Persisted verbatim (by {@link #name()}) into
 * {@code PHOTO.capture_date_source}.
 */
public enum CaptureDateSource {
    EXIF_ORIGINAL,
    EXIF_DIGITIZED,
    /**
     * Sourced from a video container's creation-date atom/tag (e.g. MP4 {@code mvhd}/{@code
     * creation_time}, QuickTime {@code com.apple.quicktime.creationdate}) via {@link
     * VideoMetadataExtractor}. Videos have no EXIF, so this is their highest-priority source.
     */
    CONTAINER_METADATA,
    FILESYSTEM
}
