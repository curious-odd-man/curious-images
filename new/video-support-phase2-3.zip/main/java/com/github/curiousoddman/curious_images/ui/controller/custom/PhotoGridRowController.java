package com.github.curiousoddman.curious_images.ui.controller.custom;

import com.github.curiousoddman.curious_images.model.LoadedFxml;
import com.github.curiousoddman.curious_images.model.GridCellData;
import com.github.curiousoddman.curious_images.model.Media;
import com.github.curiousoddman.curious_images.model.bundle.GridCellResources;
import com.github.curiousoddman.curious_images.ui.FxmlLoader;
import com.github.curiousoddman.curious_images.ui.FxmlView;
import com.github.curiousoddman.curious_images.ui.nodes.photogrid.PhotoRowCell;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.HBox;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.function.Consumer;

/**
 * Controller for one visible row of the virtualized media grid ({@code photo_grid_row.fxml}) — the
 * graphic of one {@link PhotoRowCell} ({@code ListView<PhotoGridRow>} cell).
 * <p>
 * Holds a pool of {@link GridCellController} image slots, grown lazily as the column count
 * increases and never shrunk — extra slots beyond the current row's media count are just hidden
 * ({@link GridCellController#showEmpty()}), so growing the column count back up after a shrink
 * doesn't need to reload any FXML.
 * <p>
 * Because {@code ListView} only instantiates enough {@link PhotoRowCell}s to cover the visible
 * viewport plus a small buffer (and recycles them as the user scrolls), the total number of live
 * {@link GridCellController} instances stays bounded regardless of how many thousands of photos
 * are in the selection.
 * <p>
 * <b>Scope:</b> {@code prototype}, not the app's usual singleton {@code @Component} — a fresh
 * instance is created every time a {@link PhotoRowCell} loads {@code photo_grid_row.fxml}.
 */
@Component
@Scope("prototype")
@RequiredArgsConstructor
public class PhotoGridRowController implements Initializable {

    private final FxmlLoader fxmlLoader;

    @FXML
    private HBox rowBox;

    private final List<GridCellController> pool = new ArrayList<>();

    private ObservableValue<Number> thumbnailSize;
    private Consumer<Media>      onPhotoClicked;
    private GridCellResources     gridCellResources;

    @Getter
    private long showToken;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Cells are configured entirely via bindOnce()/showRow() below.
        if (resources instanceof GridCellResources cellResources) {
            gridCellResources = cellResources;
        }
    }

    public void bindOnce(ObservableValue<Number> thumbnailSize,
                         Consumer<Media> onPhotoClicked) {
        this.thumbnailSize = thumbnailSize;
        this.onPhotoClicked = onPhotoClicked;
    }

    public List<GridCellController> getCellControllers() {
        return List.copyOf(pool);
    }

    public void showRow(List<GridCellData> photos) {
        showToken++;
        ensurePoolSize(photos.size());

        for (int i = 0; i < pool.size(); i++) {
            GridCellController cell = pool.get(i);
            if (i < photos.size()) {
                GridCellData photo = photos.get(i);
                cell.showPlaceholder(photo);
            } else {
                cell.showEmpty();
            }
        }
    }

    /**
     * Applies a looked-up image to whichever pool slot is currently showing {@code media} — a
     * no-op if that slot has since been recycled to a different media, or {@code media} isn't
     * part of this row any more. Callers should also check {@link #getShowToken()} against a
     * captured value before calling this, to avoid the (harmless but wasted) lookup-vs-slot
     * mismatch entirely.
     */
    public void applyImage(GridCellData photo) {
        for (GridCellController cell : pool) {
            GridCellData current = cell.getGridCellData();
            if (current != null && Objects.equals(current.mediaId(), photo.mediaId())) {
                cell.showImage(photo);
                return;
            }
        }
    }

    private void ensurePoolSize(int minSize) {
        while (pool.size() < minSize) {
            LoadedFxml<GridCellController> loaded     = fxmlLoader.load(FxmlView.PHOTO_CELL, gridCellResources);
            GridCellController             controller = loaded.controller();
            controller.bindThumbnailSize(thumbnailSize);
            controller.setOnPhotoClicked(onPhotoClicked);
            pool.add(controller);
            rowBox.getChildren()
                  .add(loaded.parent());
        }
    }
}
